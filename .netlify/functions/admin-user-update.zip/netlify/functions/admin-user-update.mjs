
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
var cachedConnection = null;
async function connectDb() {
  if (cachedConnection && cachedConnection.readyState === 1) {
    return cachedConnection;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI env var is not set");
  }
  cachedConnection = await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 8e3
  });
  return cachedConnection;
}
var userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    // account status: pending = awaiting approval, active = approved, deactivated = admin disabled
    status: { type: String, enum: ["pending", "active", "deactivated"], default: "pending" },
    resetToken: String,
    resetTokenExpires: Date,
    approvedAt: Date,
    approvedBy: String,
    deletedAt: Date
  },
  { timestamps: true }
);
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetToken;
  delete obj.resetTokenExpires;
  return obj;
};
var User = mongoose.models.User || mongoose.model("User", userSchema);
async function authUser(req) {
  const header = req.headers.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return null;
  const secret = process.env.JWT_SECRET;
  if (!secret) return null;
  try {
    const decoded = jwt.verify(token, secret);
    const user = await User.findById(decoded.id);
    if (!user || user.status !== "active" || user.deletedAt) return null;
    return user;
  } catch {
    return null;
  }
}
async function authAdmin(req) {
  const user = await authUser(req);
  return user && user.role === "admin" ? user : null;
}
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
var DEFAULT_PASSWORD = process.env.DEFAULT_USER_PASSWORD;
if (!DEFAULT_PASSWORD) {
  console.warn("DEFAULT_USER_PASSWORD env var is not set");
}
function hashPassword(pw) {
  return bcrypt.hash(pw, 10);
}

// netlify/functions/admin-user-update.mjs
var admin_user_update_default = async (req) => {
  try {
    const { id, action } = await req.json();
    const valid = ["activate", "deactivate", "delete", "reset-password", "make-admin", "revoke-admin"];
    if (!id || !valid.includes(action)) {
      return json({ message: "A valid user id and action are required.", codes: valid }, 400);
    }
    await connectDb();
    const admin = await authAdmin(req);
    if (!admin) return json({ message: "Admins only." }, 403);
    const target = await User.findById(id);
    if (!target) return json({ message: "User not found." }, 404);
    if (String(target._id) === String(admin._id) && ["deactivate", "delete", "revoke-admin"].includes(action)) {
      return json({ message: "You cannot deactivate, delete, or demote your own account." }, 400);
    }
    switch (action) {
      case "activate":
        target.status = "active";
        target.deletedAt = null;
        break;
      case "deactivate":
        target.status = "deactivated";
        break;
      case "delete":
        target.deletedAt = /* @__PURE__ */ new Date();
        target.status = "deactivated";
        break;
      case "reset-password":
        target.password = await hashPassword(DEFAULT_PASSWORD);
        break;
      case "make-admin":
        target.role = "admin";
        break;
      case "revoke-admin":
        target.role = "user";
        break;
    }
    await target.save();
    return json({ message: `User ${action.replace("-", " ")}d.`, user: target });
  } catch (err) {
    return json({ message: err.message }, 500);
  }
};
var config = { path: "/api/admin/user-update" };
export {
  config,
  admin_user_update_default as default
};
