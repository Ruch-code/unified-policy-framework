
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import crypto from "crypto";
var cachedConnection = null;
async function connectDb() {
  if (cachedConnection && cachedConnection.readyState === 1) {
    return cachedConnection;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI env var is not set");
  }
  cachedConnection = await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 8e3
  });
  return cachedConnection;
}
var userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    status: { type: String, enum: ["pending", "active", "deactivated"], default: "pending" },
    resetToken: String,
    resetTokenExpires: Date,
    approvedAt: Date,
    approvedBy: String,
    deletedAt: Date
  },
  { timestamps: true }
);
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetToken;
  delete obj.resetTokenExpires;
  return obj;
};
var User = mongoose.models.User || mongoose.model("User", userSchema);
var getSecret = () => {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error("JWT_SECRET env var is not set");
  return secret;
};
var verifyToken = async (token) => {
  const secret = getSecret();
  const [header, payload, sig] = token.split(".");
  const data = `${header}.${payload}`;
  const expected = crypto.createHmac("sha256", secret).update(data).digest();
  if (!crypto.timingSafeEqual(Buffer.from(sig.replace(/-/g, "+").replace(/_/g, "/"), "base64"), expected)) {
    throw new Error("Invalid signature");
  }
  const p = JSON.parse(Buffer.from(payload.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString());
  if (p.exp * 1e3 < Date.now()) throw new Error("Token expired");
  return p;
};
var authUser = async (req) => {
  const auth = req.headers.get("authorization");
  if (!auth || !auth.startsWith("Bearer ")) return null;
  try {
    return await verifyToken(auth.slice(7));
  } catch {
    return null;
  }
};
var authAdmin = async (req) => {
  const user = await authUser(req);
  if (!user || user.role !== "admin") return null;
  return user;
};
var hashPassword = async (password) => {
  return await bcrypt.hash(password, 12);
};
var DEFAULT_PASSWORD = process.env.DEFAULT_USER_PASSWORD || "";
var json = (data, status = 200) => {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
};

// netlify/functions/admin-user-update.mjs
var admin_user_update_default = async (req) => {
  try {
    const { id, action } = await req.json();
    const valid = ["activate", "deactivate", "delete", "reset-password", "make-admin", "revoke-admin"];
    if (!id || !valid.includes(action)) {
      return json({ message: "A valid user id and action are required.", codes: valid }, 400);
    }
    await connectDb();
    const admin = await authAdmin(req);
    if (!admin) return json({ message: "Admins only." }, 403);
    const target = await User.findById(id);
    if (!target) return json({ message: "User not found." }, 404);
    if (String(target._id) === String(admin._id) && ["deactivate", "delete", "revoke-admin"].includes(action)) {
      return json({ message: "You cannot deactivate, delete, or demote your own account." }, 400);
    }
    switch (action) {
      case "activate":
        target.status = "active";
        target.deletedAt = null;
        break;
      case "deactivate":
        target.status = "deactivated";
        break;
      case "delete":
        target.deletedAt = /* @__PURE__ */ new Date();
        target.status = "deactivated";
        break;
      case "reset-password":
        target.password = await hashPassword(DEFAULT_PASSWORD);
        break;
      case "make-admin":
        target.role = "admin";
        break;
      case "revoke-admin":
        target.role = "user";
        break;
    }
    await target.save();
    return json({ message: `User ${action.replace("-", " ")}d.`, user: target });
  } catch (err) {
    return json({ message: err.message }, 500);
  }
};
var config = { path: "/api/admin/user-update" };
export {
  config,
  admin_user_update_default as default
};
