
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import crypto from "crypto";
var cachedConnection = null;
async function connectDb() {
  if (cachedConnection && cachedConnection.readyState === 1) {
    return cachedConnection;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI env var is not set");
  }
  cachedConnection = await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 8e3
  });
  return cachedConnection;
}
var userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    status: { type: String, enum: ["pending", "active", "deactivated"], default: "pending" },
    resetToken: String,
    resetTokenExpires: Date,
    approvedAt: Date,
    approvedBy: String,
    deletedAt: Date
  },
  { timestamps: true }
);
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetToken;
  delete obj.resetTokenExpires;
  return obj;
};
var User = mongoose.models.User || mongoose.model("User", userSchema);
var getSecret = () => {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error("JWT_SECRET env var is not set");
  return secret;
};
var base64url = (buf) => Buffer.from(buf).toString("base64").replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
var b64u = (s) => Buffer.from(s).toString("base64").replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
var signToken = async (user) => {
  const secret = getSecret();
  const header = b64u(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const now = Math.floor(Date.now() / 1e3);
  const payload = b64u(JSON.stringify({ id: user._id, email: user.email, role: user.role, iat: now, exp: now + 604800 }));
  const data = `${header}.${payload}`;
  const sig = crypto.createHmac("sha256", secret).update(data).digest();
  return `${data}.${base64url(sig)}`;
};
var DEFAULT_PASSWORD = process.env.DEFAULT_USER_PASSWORD || "";
var json = (data, status = 200) => {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
};
var seedAdmin = async () => {
  const adminEmail = process.env.ADMIN_EMAIL?.toLowerCase();
  const adminPass = process.env.ADMIN_PASSWORD;
  if (!adminEmail || !adminPass) return;
  const existing = await User.findOne({ email: adminEmail });
  if (!existing) {
    const hash = await bcrypt.hash(adminPass, 12);
    await User.create({ name: "Admin", email: adminEmail, password: hash, role: "admin", status: "active", approvedAt: /* @__PURE__ */ new Date() });
    console.log("Seeded admin user:", adminEmail);
  }
};

// netlify/functions/auth-login.mjs
import bcrypt2 from "bcryptjs";
var auth_login_default = async (req) => {
  try {
    const { email, password } = await req.json();
    if (!email || !password) return json({ message: "Email and password required." }, 400);
    await connectDb();
    await seedAdmin();
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return json({ message: "Invalid credentials." }, 401);
    if (user.deletedAt) return json({ message: "Invalid credentials." }, 401);
    const ok = await bcrypt2.compare(password, user.password);
    if (!ok) return json({ message: "Invalid credentials." }, 401);
    if (user.status === "pending") {
      return json({ message: "Your account is awaiting admin approval." }, 403);
    }
    if (user.status === "deactivated") {
      return json({ message: "Your account has been deactivated. Contact an admin." }, 403);
    }
    const token = signToken(user);
    const defaultPw = process.env.DEFAULT_USER_PASSWORD;
    return json({ token, user, isDefaultPassword: !!defaultPw && password === defaultPw });
  } catch (err) {
    return json({ message: err.message }, 500);
  }
};
var config = { path: "/api/auth/login" };
export {
  config,
  auth_login_default as default
};
