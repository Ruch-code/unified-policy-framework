
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/newsletter.js
import mongoose2 from "mongoose";

// netlify/functions/_shared/auth.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
var cachedConnection = null;
async function connectDb() {
  if (cachedConnection && cachedConnection.readyState === 1) {
    return cachedConnection;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI env var is not set");
  }
  cachedConnection = await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 8e3
  });
  return cachedConnection;
}
var userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    // account status: pending = awaiting approval, active = approved, deactivated = admin disabled
    status: { type: String, enum: ["pending", "active", "deactivated"], default: "pending" },
    resetToken: String,
    resetTokenExpires: Date,
    approvedAt: Date,
    approvedBy: String,
    deletedAt: Date
  },
  { timestamps: true }
);
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetToken;
  delete obj.resetTokenExpires;
  return obj;
};
var User = mongoose.models.User || mongoose.model("User", userSchema);
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
var DEFAULT_PASSWORD = process.env.DEFAULT_USER_PASSWORD;
if (!DEFAULT_PASSWORD) {
  console.warn("DEFAULT_USER_PASSWORD env var is not set");
}

// netlify/functions/_shared/newsletter.js
var subscriberSchema = new mongoose2.Schema(
  {
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    source: { type: String, default: "popup" },
    unsubscribedAt: Date
  },
  { timestamps: true }
);
var newsletterSchema = new mongoose2.Schema(
  {
    title: { type: String, required: true, trim: true },
    body: { type: String, required: true },
    sentTo: { type: Number, default: 0 },
    publishedAt: Date
  },
  { timestamps: true }
);
var Subscriber = mongoose2.models.Subscriber || mongoose2.model("Subscriber", subscriberSchema);
var Newsletter = mongoose2.models.Newsletter || mongoose2.model("Newsletter", newsletterSchema);

// netlify/functions/newsletter-unsubscribe.mjs
var newsletter_unsubscribe_default = async (req) => {
  try {
    if (req.method !== "POST") return json({ message: "Method not allowed." }, 405);
    const { email } = await req.json();
    if (!email) return json({ message: "Email is required." }, 400);
    await connectDb();
    await Subscriber.findOneAndUpdate(
      { email: email.toLowerCase() },
      { $set: { unsubscribedAt: /* @__PURE__ */ new Date() } },
      { upsert: true, new: false }
    );
    return json({ message: "You have been unsubscribed." });
  } catch (err) {
    return json({ message: err.message }, 500);
  }
};
var config = { path: "/api/newsletter/unsubscribe" };
export {
  config,
  newsletter_unsubscribe_default as default
};
