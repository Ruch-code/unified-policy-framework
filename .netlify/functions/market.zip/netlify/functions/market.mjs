
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
var userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    status: { type: String, enum: ["pending", "active", "deactivated"], default: "pending" },
    resetToken: String,
    resetTokenExpires: Date,
    approvedAt: Date,
    approvedBy: String,
    deletedAt: Date
  },
  { timestamps: true }
);
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetToken;
  delete obj.resetTokenExpires;
  return obj;
};
var User = mongoose.models.User || mongoose.model("User", userSchema);
var DEFAULT_PASSWORD = process.env.DEFAULT_USER_PASSWORD || "";
var json = (data, status = 200) => {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
};

// netlify/functions/market.mjs
var config = { path: "/api/market" };
var UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
var cache = { at: 0, payload: null };
var CACHE_TTL = 6e4;
function cached(payload) {
  const now = Date.now();
  if (cache.payload && now - cache.at < CACHE_TTL) return cache.payload;
  cache = { at: now, payload };
  return payload;
}
function num(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}
async function fetchNseIndices() {
  const jar = {};
  const cookieHeader = (prefix) => Object.entries(jar).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("; ");
  const setCookies = (headers) => {
    const raw = headers.getSetCookie && typeof headers.getSetCookie === "function" ? headers.getSetCookie() : headers.get ? headers.getAll("set-cookie") : [];
    for (const c of raw) {
      const [pair] = c.split(";");
      const eq = pair.indexOf("=");
      if (eq > 0) jar[pair.slice(0, eq).trim()] = pair.slice(eq + 1);
    }
  };
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const warm = await fetch("https://www.nseindia.com/", {
        headers: { "User-Agent": UA, Referer: "https://www.nseindia.com/" }
      });
      setCookies(warm.headers);
      const api = await fetch("https://www.nseindia.com/api/allIndices", {
        headers: {
          "User-Agent": UA,
          Referer: "https://www.nseindia.com/market-data/indices",
          Cookie: cookieHeader()
        }
      });
      if (api.status === 429) {
        if (!warm.ok) await new Promise((r) => setTimeout(r, 800));
        continue;
      }
      if (!api.ok) continue;
      const data = await api.json();
      const rows = data && data.data || [];
      const pick = (name) => {
        const row = rows.find((r) => r && r.index === name);
        if (!row) return null;
        const last = num(row.last);
        const prev = num(row.previousClose);
        const open = num(row.open);
        return {
          name: row.index,
          last,
          previousClose: prev,
          change: last != null && prev != null ? +(last - prev).toFixed(2) : null,
          changePercent: num(row.percentChange),
          open,
          high: num(row.high),
          low: num(row.low),
          timestamp: data.timestamp || row.timestamp,
          source: "nse"
        };
      };
      const out = {
        "NIFTY 50": pick("NIFTY 50"),
        "NIFTY BANK": pick("NIFTY BANK"),
        "INDIA VIX": pick("INDIA VIX")
      };
      const ok = Object.values(out).filter(Boolean).length;
      if (ok > 0) return { ok: out, source: "nse" };
    } catch {
    }
  }
  return { ok: {}, source: "nse" };
}
async function fetchSensexYahoo() {
  for (const host of ["query1.finance.yahoo.com", "query2.finance.yahoo.com"]) {
    try {
      const url = `https://${host}/v8/finance/chart/%5EBSESN?interval=1d&range=5d`;
      const res = await fetch(url, { headers: { "User-Agent": UA, Accept: "application/json" } });
      if (res.status === 429) continue;
      if (!res.ok) continue;
      const d = await res.json();
      const r = d?.chart?.result?.[0]?.meta;
      if (!r) continue;
      const last = num(r.regularMarketPrice);
      const prev = num(r.regularMarketPreviousClose);
      return {
        name: "SENSEX",
        last,
        previousClose: prev,
        change: last != null && prev != null ? +(last - prev).toFixed(2) : null,
        changePercent: num(r.regularMarketChangePercent),
        open: num(r.regularMarketOpen),
        high: num(r.regularMarketDayHigh),
        low: num(r.regularMarketDayLow),
        timestamp: r.regularMarketTime ? new Date(r.regularMarketTime * 1e3).toISOString() : null,
        source: "yahoo"
      };
    } catch {
    }
  }
  return null;
}
async function fetchSensexTwelveData() {
  const apiKey = process.env.TWELVE_DATA_API_KEY;
  if (!apiKey) return null;
  try {
    const res = await fetch(`https://api.twelvedata.com/quote?symbol=BSESN&apikey=${encodeURIComponent(apiKey)}`, {
      headers: { "User-Agent": UA, Accept: "application/json" }
    });
    if (!res.ok) return null;
    const d = await res.json();
    if (d.status === "error" || d.code) return null;
    const last = num(d.close) ?? num(d.price);
    const prev = num(d.previous_close);
    const open = num(d.open);
    return {
      name: "SENSEX",
      last,
      previousClose: prev,
      change: last != null && prev != null ? +(last - prev).toFixed(2) : null,
      changePercent: num(d.percent_change),
      open,
      high: num(d.high),
      low: num(d.low),
      timestamp: d.datetime,
      source: "twelvedata"
    };
  } catch {
    return null;
  }
}
var market_default = async (req) => {
  try {
    const now = Date.now();
    if (cache.payload && now - cache.at < CACHE_TTL) return json(cache.payload);
    const [nse, sensexYahoo, sensexTwelve] = await Promise.all([
      fetchNseIndices(),
      fetchSensexYahoo(),
      fetchSensexTwelveData()
    ]);
    const data = { ...nse.ok };
    const sensex = sensexYahoo || sensexTwelve;
    if (sensex) data["SENSEX"] = sensex;
    const rows = Object.values(data).filter(Boolean);
    const okCount = rows.length;
    const quoteTime = rows.map((r) => r.timestamp).filter(Boolean).sort().pop();
    return json(cached({
      indices: data,
      updatedAt: quoteTime || (/* @__PURE__ */ new Date()).toISOString(),
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      okCount,
      requested: 4
    }));
  } catch (e) {
    console.error("market function error:", e);
    return json({ message: "Internal server error." }, 500);
  }
};
export {
  config,
  market_default as default
};
