
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/newsletter.js
import mongoose2 from "mongoose";

// netlify/functions/_shared/auth.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import crypto from "crypto";
var cachedConnection = null;
async function connectDb() {
  if (cachedConnection && cachedConnection.readyState === 1) {
    return cachedConnection;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI env var is not set");
  }
  cachedConnection = await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 8e3
  });
  return cachedConnection;
}
var userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    status: { type: String, enum: ["pending", "active", "deactivated"], default: "pending" },
    resetToken: String,
    resetTokenExpires: Date,
    approvedAt: Date,
    approvedBy: String,
    deletedAt: Date
  },
  { timestamps: true }
);
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetToken;
  delete obj.resetTokenExpires;
  return obj;
};
var User = mongoose.models.User || mongoose.model("User", userSchema);
var getSecret = () => {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error("JWT_SECRET env var is not set");
  return secret;
};
var verifyToken = async (token) => {
  const secret = getSecret();
  const [header, payload, sig] = token.split(".");
  const data = `${header}.${payload}`;
  const expected = crypto.createHmac("sha256", secret).update(data).digest();
  if (!crypto.timingSafeEqual(Buffer.from(sig.replace(/-/g, "+").replace(/_/g, "/"), "base64"), expected)) {
    throw new Error("Invalid signature");
  }
  const p = JSON.parse(Buffer.from(payload.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString());
  if (p.exp * 1e3 < Date.now()) throw new Error("Token expired");
  return p;
};
var authUser = async (req) => {
  const auth = req.headers.get("authorization");
  if (!auth || !auth.startsWith("Bearer ")) return null;
  try {
    return await verifyToken(auth.slice(7));
  } catch {
    return null;
  }
};
var authAdmin = async (req) => {
  const user = await authUser(req);
  if (!user || user.role !== "admin") return null;
  return user;
};
var DEFAULT_PASSWORD = process.env.DEFAULT_USER_PASSWORD || "";
var json = (data, status = 200) => {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
};

// netlify/functions/_shared/newsletter.js
var subscriberSchema = new mongoose2.Schema(
  {
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    source: { type: String, default: "popup" },
    unsubscribedAt: Date
  },
  { timestamps: true }
);
var newsletterSchema = new mongoose2.Schema(
  {
    title: { type: String, required: true, trim: true },
    body: { type: String, required: true },
    sentTo: { type: Number, default: 0 },
    publishedAt: Date
  },
  { timestamps: true }
);
var Subscriber = mongoose2.models.Subscriber || mongoose2.model("Subscriber", subscriberSchema);
var Newsletter = mongoose2.models.Newsletter || mongoose2.model("Newsletter", newsletterSchema);
function getFrom() {
  return process.env.NEWSLETTER_FROM || "onboarding@resend.dev";
}

// netlify/functions/newsletter-publish.mjs
import { Resend } from "resend";
var SITE = "https://spectacular-genie-bda511.netlify.app";
var UNSUB_URL = SITE + "/api/newsletter/unsubscribe";
var newsletter_publish_default = async (req) => {
  try {
    if (req.method !== "POST") return json({ message: "Method not allowed." }, 405);
    await connectDb();
    const admin = await authAdmin(req);
    if (!admin) return json({ message: "Not authorized." }, 401);
    const { title, body } = await req.json();
    if (!title || !body) return json({ message: "Title and body are required." }, 400);
    const subscribers = await Subscriber.find({ unsubscribedAt: { $exists: false } });
    const emails = subscribers.map((s) => s.email);
    const html = `
      <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:24px">
        <h1 style="color:#6d28d9;margin:0 0 12px">${title}</h1>
        <div style="color:#333;line-height:1.7;white-space:pre-wrap">${body}</div>
        <hr style="border:none;border-top:1px solid #eee;margin:24px 0" />
        <p style="color:#999;font-size:12px">You're receiving this because you subscribed to the Unified Compliance newsletter.</p>
        <a href="${UNSUB_URL}?email=%EMAIL%" style="color:#999;font-size:12px">Unsubscribe</a>
      </div>`;
    const doc = await Newsletter.create({ title, body, sentTo: emails.length, publishedAt: /* @__PURE__ */ new Date() });
    let sent = 0;
    const apiKey = process.env.RESEND_API_KEY;
    if (apiKey && emails.length) {
      try {
        const resend = new Resend(apiKey);
        for (const email of emails) {
          try {
            await resend.emails.send({
              from: getFrom(),
              to: [email],
              subject: title,
              html: html.replace("%EMAIL%", encodeURIComponent(email))
            });
            sent++;
          } catch (e) {
            console.warn("Send failed for", email, e.message);
          }
        }
        await Newsletter.updateOne({ _id: doc._id }, { $set: { sentTo: sent } });
      } catch (err) {
        console.warn("Broadcast error:", err.message);
      }
    }
    const shareText = `${title} \u2014 Read the latest from the Unified Compliance newsletter.`;
    const linkedInUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(SITE)}&text=${encodeURIComponent(shareText)}`;
    return json({
      message: `Published to ${sent} of ${emails.length} subscribers.`,
      subscribers: emails.length,
      sent,
      id: doc._id,
      linkedInUrl
    });
  } catch (err) {
    return json({ message: err.message }, 500);
  }
};
var config = { path: "/api/newsletter/publish" };
export {
  config,
  newsletter_publish_default as default
};
