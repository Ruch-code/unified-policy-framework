
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import crypto from "crypto";
var cachedConnection = null;
async function connectDb() {
  if (cachedConnection && cachedConnection.readyState === 1) {
    return cachedConnection;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI env var is not set");
  }
  cachedConnection = await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 8e3
  });
  return cachedConnection;
}
var userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    status: { type: String, enum: ["pending", "active", "deactivated"], default: "pending" },
    resetToken: String,
    resetTokenExpires: Date,
    approvedAt: Date,
    approvedBy: String,
    deletedAt: Date
  },
  { timestamps: true }
);
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetToken;
  delete obj.resetTokenExpires;
  return obj;
};
var User = mongoose.models.User || mongoose.model("User", userSchema);
var getSecret = () => {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error("JWT_SECRET env var is not set");
  return secret;
};
var verifyToken = async (token) => {
  const secret = getSecret();
  const [header, payload, sig] = token.split(".");
  const data = `${header}.${payload}`;
  const expected = crypto.createHmac("sha256", secret).update(data).digest();
  if (!crypto.timingSafeEqual(Buffer.from(sig.replace(/-/g, "+").replace(/_/g, "/"), "base64"), expected)) {
    throw new Error("Invalid signature");
  }
  const p = JSON.parse(Buffer.from(payload.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString());
  if (p.exp * 1e3 < Date.now()) throw new Error("Token expired");
  return p;
};
var authUser = async (req) => {
  const auth = req.headers.get("authorization");
  if (!auth || !auth.startsWith("Bearer ")) return null;
  try {
    return await verifyToken(auth.slice(7));
  } catch {
    return null;
  }
};
var hashPassword = async (password) => {
  return await bcrypt.hash(password, 12);
};
var DEFAULT_PASSWORD = process.env.DEFAULT_USER_PASSWORD || "";
var json = (data, status = 200) => {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
};

// netlify/functions/auth-password.mjs
import bcrypt2 from "bcryptjs";
var auth_password_default = async (req) => {
  try {
    const { currentPassword, newPassword } = await req.json();
    await connectDb();
    const user = await authUser(req);
    if (!user) return json({ message: "Not authorized." }, 401);
    if (!newPassword || newPassword.length < 6) {
      return json({ message: "New password must be at least 6 characters." }, 400);
    }
    const ok = await bcrypt2.compare(currentPassword || "", user.password);
    if (!ok) return json({ message: "Current password is incorrect." }, 400);
    user.password = await hashPassword(newPassword);
    await user.save();
    return json({ message: "Password updated successfully." });
  } catch (err) {
    return json({ message: err.message }, 500);
  }
};
var config = { path: "/api/auth/password" };
export {
  config,
  auth_password_default as default
};
