
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
var cachedConnection = null;
async function connectDb() {
  if (cachedConnection && cachedConnection.readyState === 1) {
    return cachedConnection;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI env var is not set");
  }
  cachedConnection = await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 8e3
  });
  return cachedConnection;
}
var userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    status: { type: String, enum: ["pending", "active", "deactivated"], default: "pending" },
    resetToken: String,
    resetTokenExpires: Date,
    approvedAt: Date,
    approvedBy: String,
    deletedAt: Date
  },
  { timestamps: true }
);
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetToken;
  delete obj.resetTokenExpires;
  return obj;
};
var User = mongoose.models.User || mongoose.model("User", userSchema);
var hashPassword = async (password) => {
  return await bcrypt.hash(password, 12);
};
var DEFAULT_PASSWORD = process.env.DEFAULT_USER_PASSWORD || "";
var json = (data, status = 200) => {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
};

// netlify/functions/auth-register.mjs
import { Resend } from "resend";
async function notifyAdmin(name, email) {
  const apiKey = process.env.RESEND_API_KEY;
  const adminEmail = (process.env.ADMIN_EMAIL || "").toLowerCase().trim();
  if (!apiKey || !adminEmail) {
    console.warn("Email notification skipped: RESEND_API_KEY or ADMIN_EMAIL not set");
    return;
  }
  try {
    const resend = new Resend(apiKey);
    await resend.emails.send({
      from: process.env.RESEND_FROM || "onboarding@resend.dev",
      to: [adminEmail],
      subject: "New access request: " + name,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:24px">
          <h2 style="color:#6d28d9;margin:0 0 8px">New access request</h2>
          <p>A new account is awaiting your approval on the Compliance Framework.</p>
          <table style="border-collapse:collapse;margin:16px 0">
            <tr><td style="padding:6px 12px 6px 0;color:#555">Name</td><td style="padding:6px 0;font-weight:600">${name}</td></tr>
            <tr><td style="padding:6px 12px 6px 0;color:#555">Email</td><td style="padding:6px 0;font-weight:600">${email}</td></tr>
          </table>
          <p style="margin:0">Approve or reject it in the admin panel:</p>
          <a href="https://spectacular-genie-bda511.netlify.app/admin"
             style="display:inline-block;margin-top:12px;background:#6d28d9;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:600">
            Open Admin Panel
          </a>
        </div>`
    });
  } catch (err) {
    console.warn("Email notification failed:", err.message);
  }
}
var auth_register_default = async (req) => {
  try {
    const { name, email } = await req.json();
    if (!name || !email || !email.includes("@")) {
      return json({ message: "Name and a valid email are required." }, 400);
    }
    await connectDb();
    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
      return json({ message: "A user with that email already exists." }, 400);
    }
    await User.create({
      name,
      email: email.toLowerCase(),
      password: await hashPassword(DEFAULT_PASSWORD),
      status: "pending"
    });
    await notifyAdmin(name, email.toLowerCase());
    return json(
      {
        message: "Account created and awaiting approval. You will be able to sign in once an admin approves you. Your temporary password is " + DEFAULT_PASSWORD,
        defaultPassword: DEFAULT_PASSWORD
      },
      201
    );
  } catch (err) {
    return json({ message: err.message }, 500);
  }
};
var config = { path: "/api/auth/register" };
export {
  config,
  auth_register_default as default
};
