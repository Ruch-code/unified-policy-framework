
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/visitor-count.mjs
import { getStore } from "@netlify/blobs";
var STORE = "visitor-counter";
var KEY = "total";
var visitor_count_default = async (req, context) => {
  try {
    const store = await getStore({ name: STORE, ...context.blobs });
    const current = Number(await store.get(KEY) || 0);
    const next = current + 1;
    await store.set(KEY, String(next));
    return Response.json({ total: next });
  } catch (err) {
    return Response.json({ total: 0, error: String(err?.message || err) }, { status: 500 });
  }
};
var config = {
  path: "/api/visit"
};
export {
  config,
  visitor_count_default as default
};
