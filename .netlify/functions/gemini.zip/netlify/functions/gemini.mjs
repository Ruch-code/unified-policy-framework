
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/newsletter.js
import mongoose2 from "mongoose";

// netlify/functions/_shared/auth.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
var userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    status: { type: String, enum: ["pending", "active", "deactivated"], default: "pending" },
    resetToken: String,
    resetTokenExpires: Date,
    approvedAt: Date,
    approvedBy: String,
    deletedAt: Date
  },
  { timestamps: true }
);
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetToken;
  delete obj.resetTokenExpires;
  return obj;
};
var User = mongoose.models.User || mongoose.model("User", userSchema);
var DEFAULT_PASSWORD = process.env.DEFAULT_USER_PASSWORD || "";
var json = (data, status = 200) => {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
};

// netlify/functions/_shared/newsletter.js
var subscriberSchema = new mongoose2.Schema(
  {
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    source: { type: String, default: "popup" },
    unsubscribedAt: Date
  },
  { timestamps: true }
);
var newsletterSchema = new mongoose2.Schema(
  {
    title: { type: String, required: true, trim: true },
    body: { type: String, required: true },
    sentTo: { type: Number, default: 0 },
    publishedAt: Date
  },
  { timestamps: true }
);
var Subscriber = mongoose2.models.Subscriber || mongoose2.model("Subscriber", subscriberSchema);
var Newsletter = mongoose2.models.Newsletter || mongoose2.model("Newsletter", newsletterSchema);

// netlify/functions/gemini.mjs
var GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent";
var config = { path: "/api/gemini" };
var gemini_default = async (req) => {
  try {
    if (req.method !== "POST") return json({ message: "Method not allowed." }, 405);
    const { query } = await req.json();
    if (!query || query.trim().length < 3) return json({ message: "Query too short." }, 400);
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return json({ message: "Gemini API key not configured." }, 500);
    const body = {
      contents: [{ role: "user", parts: [{ text: `You are a GRC (Governance, Risk, Compliance) assistant. Answer the following question accurately, with concrete references to frameworks (SOC 2, ISO 27001, PCI-DSS, HIPAA, NIST CSF, GDPR, DPDPA, CCPA/CPRA, COPPA, LGPD, PDPA, PIPL, FedRAMP, CJIS) where relevant. If the question is about a specific framework, cite the relevant control, article, or requirement. Structure the answer with a short summary and 3-5 actionable bullets. Do not fabricate citations.` + query }] }]
    };
    const res = await fetch(GEMINI_URL + "?key=" + apiKey, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (!res.ok) return json({ message: "Gemini API error." }, 502);
    const data = await res.json();
    const answer = data?.candidates?.[0]?.content?.parts?.[0]?.text || "Gemini returned an empty response.";
    return json({ answer });
  } catch (e) {
    console.error("Gemini function error:", e);
    return json({ message: "Internal server error." }, 500);
  }
};
export {
  config,
  gemini_default as default
};
