
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/newsletter.js
import mongoose2 from "mongoose";

// netlify/functions/_shared/auth.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
var cachedConnection = null;
async function connectDb() {
  if (cachedConnection && cachedConnection.readyState === 1) {
    return cachedConnection;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI env var is not set");
  }
  cachedConnection = await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 8e3
  });
  return cachedConnection;
}
var userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    status: { type: String, enum: ["pending", "active", "deactivated"], default: "pending" },
    resetToken: String,
    resetTokenExpires: Date,
    approvedAt: Date,
    approvedBy: String,
    deletedAt: Date
  },
  { timestamps: true }
);
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetToken;
  delete obj.resetTokenExpires;
  return obj;
};
var User = mongoose.models.User || mongoose.model("User", userSchema);
var DEFAULT_PASSWORD = process.env.DEFAULT_USER_PASSWORD || "";
var json = (data, status = 200) => {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
};

// netlify/functions/_shared/newsletter.js
var subscriberSchema = new mongoose2.Schema(
  {
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    source: { type: String, default: "popup" },
    unsubscribedAt: Date
  },
  { timestamps: true }
);
var newsletterSchema = new mongoose2.Schema(
  {
    title: { type: String, required: true, trim: true },
    body: { type: String, required: true },
    sentTo: { type: Number, default: 0 },
    publishedAt: Date
  },
  { timestamps: true }
);
var Subscriber = mongoose2.models.Subscriber || mongoose2.model("Subscriber", subscriberSchema);
var Newsletter = mongoose2.models.Newsletter || mongoose2.model("Newsletter", newsletterSchema);
function getFrom() {
  return process.env.NEWSLETTER_FROM || "onboarding@resend.dev";
}

// netlify/functions/newsletter-subscribe.mjs
import { Resend } from "resend";
var SITE = "https://spectacular-genie-bda511.netlify.app";
var newsletter_subscribe_default = async (req) => {
  try {
    if (req.method !== "POST") return json({ message: "Method not allowed." }, 405);
    const { email } = await req.json();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return json({ message: "A valid email is required." }, 400);
    }
    await connectDb();
    const normalized = email.toLowerCase();
    const sub = await Subscriber.findOneAndUpdate(
      { email: normalized },
      { $set: { source: "popup" }, $unset: { unsubscribedAt: "" } },
      { upsert: true, new: true }
    );
    const isNew = sub.createdAt && Date.now() - new Date(sub.createdAt).getTime() < 5e3;
    const apiKey = process.env.RESEND_API_KEY;
    if (apiKey) {
      try {
        const resend = new Resend(apiKey);
        await resend.emails.send({
          from: getFrom(),
          to: [normalized],
          subject: "You're subscribed! \u{1F44B}",
          html: `
            <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;padding:24px">
              <h2 style="color:#6d28d9;margin:0 0 8px">Welcome to the Unified Compliance newsletter!</h2>
              <p style="color:#333">Thanks for subscribing. You'll get practical, no-jargon guidance on certifications, security compliance, privacy, and how to choose what matters for your business.</p>
              <p style="color:#333">In the meantime, try the <strong>Certification Advisor</strong> to see your tailored upskill roadmap:</p>
              <a href="${SITE}" style="display:inline-block;margin-top:12px;background:#6d28d9;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:600">Open the site</a>
              <p style="color:#999;font-size:12px;margin-top:24px">You can unsubscribe anytime using the link in any email.</p>
            </div>`
        });
      } catch (err) {
        console.warn("Welcome email failed:", err.message);
      }
    }
    return json({ message: isNew ? "Subscribed!" : "You are already subscribed.", subscribed: true }, isNew ? 201 : 200);
  } catch (err) {
    return json({ message: err.message }, 500);
  }
};
var config = { path: "/api/newsletter/subscribe" };
export {
  config,
  newsletter_subscribe_default as default
};
