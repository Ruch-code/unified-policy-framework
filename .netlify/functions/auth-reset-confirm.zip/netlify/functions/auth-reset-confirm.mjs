
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_shared/auth.js
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
var cachedConnection = null;
async function connectDb() {
  if (cachedConnection && cachedConnection.readyState === 1) {
    return cachedConnection;
  }
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error("MONGODB_URI env var is not set");
  }
  cachedConnection = await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 8e3
  });
  return cachedConnection;
}
var userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6 },
    role: { type: String, enum: ["user", "admin"], default: "user" },
    // account status: pending = awaiting approval, active = approved, deactivated = admin disabled
    status: { type: String, enum: ["pending", "active", "deactivated"], default: "pending" },
    resetToken: String,
    resetTokenExpires: Date,
    approvedAt: Date,
    approvedBy: String,
    deletedAt: Date
  },
  { timestamps: true }
);
userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  delete obj.resetToken;
  delete obj.resetTokenExpires;
  return obj;
};
var User = mongoose.models.User || mongoose.model("User", userSchema);
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
var DEFAULT_PASSWORD = process.env.DEFAULT_USER_PASSWORD;
if (!DEFAULT_PASSWORD) {
  console.warn("DEFAULT_USER_PASSWORD env var is not set");
}
function hashPassword(pw) {
  return bcrypt.hash(pw, 10);
}

// netlify/functions/auth-reset-confirm.mjs
var auth_reset_confirm_default = async (req) => {
  try {
    const { email, resetToken, newPassword } = await req.json();
    if (!email || !resetToken || !newPassword) {
      return json({ message: "Email, reset token, and new password are required." }, 400);
    }
    if (newPassword.length < 6) return json({ message: "Password must be at least 6 characters." }, 400);
    await connectDb();
    const user = await User.findOne({ email: email.toLowerCase(), deletedAt: null });
    if (!user) return json({ message: "Invalid reset request." }, 400);
    if (!user.resetToken || user.resetToken !== resetToken || !user.resetTokenExpires || user.resetTokenExpires < /* @__PURE__ */ new Date()) {
      return json({ message: "Reset token is invalid or expired." }, 400);
    }
    user.password = await hashPassword(newPassword);
    user.resetToken = null;
    user.resetTokenExpires = null;
    await user.save();
    return json({ message: "Password has been reset. You can now sign in." });
  } catch (err) {
    return json({ message: err.message }, 500);
  }
};
var config = { path: "/api/auth/reset-confirm" };
export {
  config,
  auth_reset_confirm_default as default
};
